import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.howbusy.app',
  appName: 'How Busy?',
  webDir: 'www',
  android: {
    useLegacyBridge: true
  }
};

export default config;
