create extension if not exists pgcrypto;

create table if not exists public.hb_venues (
  id uuid primary key default gen_random_uuid(),
  city text not null default 'Newcastle',
  name text not null,
  venue_type text not null,
  suburb text,
  address text not null,
  latitude double precision,
  longitude double precision,
  geofence_m integer not null default 120,
  coordinates_verified boolean not null default false,
  active boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(city,name,address)
);

create index if not exists hb_venues_newcastle_active
on public.hb_venues(city,active,coordinates_verified);

create table if not exists public.hb_presence (
  installation_id uuid not null,
  venue_id uuid not null references public.hb_venues(id) on delete cascade,
  entered_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  exited_at timestamptz,
  relationship_status text,
  crowd_answer text,
  app_version text,
  primary key (installation_id,venue_id)
);

create index if not exists hb_presence_live
on public.hb_presence(venue_id,last_seen_at)
where exited_at is null;

alter table public.hb_venues enable row level security;
alter table public.hb_presence enable row level security;

drop policy if exists hb_venues_public_read on public.hb_venues;
create policy hb_venues_public_read on public.hb_venues
for select using (active=true and coordinates_verified=true);

-- Raw presence rows are never readable by the client.
-- Aggregated venue counts are exposed through RPC only.

create or replace function public.hb_enter_venue(
 p_installation_id uuid,p_venue_id uuid,
 p_relationship_status text default null,
 p_crowd_answer text default null,
 p_app_version text default null
) returns void
language plpgsql security definer set search_path=public
as $$
begin
 if not exists (
   select 1 from hb_venues
   where id=p_venue_id and city='Newcastle'
   and active=true and coordinates_verified=true
 ) then raise exception 'Venue not active/verified'; end if;

 insert into hb_presence(
   installation_id,venue_id,entered_at,last_seen_at,exited_at,
   relationship_status,crowd_answer,app_version
 ) values (
   p_installation_id,p_venue_id,now(),now(),null,
   p_relationship_status,p_crowd_answer,p_app_version
 )
 on conflict (installation_id,venue_id) do update set
   last_seen_at=now(),exited_at=null,
   relationship_status=excluded.relationship_status,
   crowd_answer=excluded.crowd_answer,
   app_version=excluded.app_version;
end $$;

create or replace function public.hb_heartbeat(
 p_installation_id uuid,p_venue_id uuid
) returns void
language sql security definer set search_path=public
as $$
 update hb_presence set last_seen_at=now(),exited_at=null
 where installation_id=p_installation_id and venue_id=p_venue_id
$$;

create or replace function public.hb_exit_venue(
 p_installation_id uuid,p_venue_id uuid
) returns void
language sql security definer set search_path=public
as $$
 update hb_presence set exited_at=now()
 where installation_id=p_installation_id and venue_id=p_venue_id
$$;

create or replace function public.hb_venue_live(p_venue_id uuid)
returns json
language sql security definer set search_path=public
as $$
 select json_build_object(
  'people_here',count(*),
  'single',count(*) filter(where relationship_status='Single'),
  'taken',count(*) filter(where relationship_status='Taken'),
  'more_men',count(*) filter(where crowd_answer='More men'),
  'more_women',count(*) filter(where crowd_answer='More women'),
  'fifty_fifty',count(*) filter(where crowd_answer='50/50')
 )
 from hb_presence
 where venue_id=p_venue_id
 and exited_at is null
 and last_seen_at >= now()-interval '3 minutes'
$$;

create or replace function public.hb_cleanup_presence()
returns integer
language plpgsql security definer set search_path=public
as $$
declare n integer;
begin
 update hb_presence set exited_at=coalesce(exited_at,now())
 where exited_at is null
 and last_seen_at < now()-interval '3 minutes';
 get diagnostics n=row_count;
 return n;
end $$;
