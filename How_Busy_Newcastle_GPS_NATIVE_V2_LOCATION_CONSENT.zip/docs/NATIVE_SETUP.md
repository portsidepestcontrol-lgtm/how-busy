# How Busy? native GPS setup

This build uses `@capacitor-community/background-geolocation` because the browser
Geolocation API alone is not a reliable production solution for background
location on both iOS and Android. The community plugin supports iOS and Android
background location and documents the required permission/configuration. 

## 1. Install
npm install
npx cap add ios
npx cap add android
npx cap sync

## 2. iOS
In Xcode / Info.plist add:
- NSLocationWhenInUseUsageDescription
- NSLocationAlwaysAndWhenInUseUsageDescription
- UIBackgroundModes = location

The user must grant the appropriate location permission. The app cannot silently
grant itself location access.

## 3. Android
Add the location permissions required by the Android target, including fine/coarse
location and background location as applicable. The plugin also requires its
background-location notification configuration. Android 13+ requires notification
permission for the persistent background-location notification.

## 4. Supabase
Put the real SUPABASE_URL and SUPABASE_ANON_KEY into `src/background-gps.ts`.
Do not put a service-role key in the mobile app.

## 5. Venue coordinates
The app only matches venues where:
coordinates_verified = true
active = true
latitude and longitude are present.

Do not activate a venue with guessed coordinates.

## 6. Privacy
The exact phone latitude/longitude is used on-device for matching.
The presence table receives only:
- anonymous installation ID
- venue ID
- timestamps
- optional profile answers

## 7. Important store requirement
The app must clearly explain why background location is used and comply with Apple
and Google Play location/privacy policies.
