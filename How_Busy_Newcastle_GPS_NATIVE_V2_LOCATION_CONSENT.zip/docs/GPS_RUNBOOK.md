# How Busy? Newcastle GPS — production runbook

Prepared Newcastle seed records: 111.

## What is now built

1. Newcastle-only venue database.
2. Native iOS/Android background GPS layer.
3. Local nearest-venue matching.
4. Anonymous enter/heartbeat/exit presence.
5. Supabase aggregate RPC for venue live counts.
6. Automatic 3-minute expiry.
7. Server-side address geocoding function.
8. Coordinates are never guessed in the app.

## Correct activation order

### A. Create Supabase tables
Run:
`supabase/migrations/001_newcastle_gps.sql`

### B. Import venues
Import:
`supabase/newcastle_venues_seed.csv`

All venues begin with:
`coordinates_verified=false`
`active=false`

### C. Geocode
Deploy the Edge Function:
`supabase/functions/geocode-venues/index.ts`

Run it from an authenticated admin process. It writes latitude/longitude but
does NOT activate the venue.

### D. Verify
Review the coordinate on a map. For venues that are close together, tune
`geofence_m`.

### E. Activate
Only after verification:
`coordinates_verified=true`
`active=true`

### F. Native app
Run:
`npm install`
`npx cap add ios`
`npx cap add android`
`npx cap sync`

Open Xcode and Android Studio and configure the documented background-location
permissions.

## Important
The HTML file by itself cannot provide reliable background location on both
platforms. The native shell in this project is what makes the automatic GPS
feature real.
