# User-facing location explanation

Recommended first-run wording:

How Busy? uses your phone's location to work out which venue you are at and
help create live crowd information.

We use location to:
- detect when you enter a participating venue
- match you to the nearest verified venue
- create an anonymous live presence count

We do not need your name to count that presence.
Your exact GPS position is matched on your phone and is not stored in the live
presence record.

You choose whether to allow location access. The phone operating system controls
the final permission.

For automatic background venue detection, the production build requests the
background/Always location permission required by iOS/Android. The app should
not claim that location is "on automatically" without the user's OS permission.
