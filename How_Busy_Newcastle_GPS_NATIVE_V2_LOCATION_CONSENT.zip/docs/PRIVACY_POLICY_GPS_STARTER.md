# How Busy? — Location Data Summary

How Busy? uses device location to determine whether a device is inside a
participating venue geofence.

## Data minimisation
The production GPS engine performs the latitude/longitude-to-venue match on the
device. The live presence service receives an anonymous installation ID and
venue ID rather than a continuous GPS trail.

## Purpose
The purpose is to calculate live and recent crowd presence at venues and provide
crowd information to How Busy? users.

## User control
Location access is controlled by the phone's operating system. Users can deny,
change, or revoke location access.

## Other profile answers
The app may store answers the user provides during setup, such as relationship
status or crowd composition. These answers should be stored separately from
identity information and only used for the app's stated crowd-information
purpose.

## No sale
How Busy? should not sell location data or use it for unrelated advertising
without a separate lawful basis and clear user disclosure.

## Retention
Live presence records should expire automatically after the configured inactivity
window. Do not retain a historical movement trail unless a separate feature and
privacy basis are introduced.
