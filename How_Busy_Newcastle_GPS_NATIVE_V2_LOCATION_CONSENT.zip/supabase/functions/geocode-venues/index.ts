import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

const UA = "HowBusy/1.0 (venue geocoding)";
const sleep = (ms:number)=>new Promise(r=>setTimeout(r,ms));

Deno.serve(async (req) => {
  if(req.method !== "POST") return new Response("POST only",{status:405});

  const { data: venues, error } = await supabase
    .from("hb_venues")
    .select("id,name,address,suburb,city")
    .eq("city","Newcastle")
    .is("latitude",null);

  if(error) return Response.json({error:error.message},{status:500});

  let updated=0, unresolved=0;

  for(const v of venues ?? []) {
    const q = `${v.name}, ${v.address}, ${v.suburb || ""}, Newcastle NSW, Australia`;
    const url = "https://nominatim.openstreetmap.org/search?" +
      new URLSearchParams({q,format:"json",limit:"1",countrycodes:"au"}).toString();

    const r = await fetch(url,{headers:{"User-Agent":UA}});
    if(!r.ok){ await sleep(1100); continue; }
    const results = await r.json();

    if(results?.[0]) {
      await supabase.from("hb_venues").update({
        latitude:Number(results[0].lat),
        longitude:Number(results[0].lon),
        coordinates_verified:false,
        active:false
      }).eq("id",v.id);
      updated++;
    } else {
      unresolved++;
    }
    await sleep(1100);
  }

  return Response.json({updated,unresolved,total:venues?.length ?? 0});
});
