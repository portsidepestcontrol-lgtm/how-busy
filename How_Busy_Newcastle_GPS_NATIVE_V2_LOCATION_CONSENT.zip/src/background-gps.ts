import { registerPlugin } from '@capacitor/core';
import { createClient } from '@supabase/supabase-js';

type BGLocation = {
  latitude: number;
  longitude: number;
  accuracy: number;
  time: number;
};

type BackgroundGeolocationPlugin = {
  addWatcher(options: any, callback: (location: BGLocation | null, error?: any) => void): Promise<string>;
  removeWatcher(options: { id: string }): Promise<void>;
};

const BackgroundGeolocation =
  registerPlugin<BackgroundGeolocationPlugin>('BackgroundGeolocation');

const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const MAX_ACCURACY_M = 150;
const DEFAULT_RADIUS_M = 120;
const EXIT_GRACE_MS = 180_000;
const HEARTBEAT_MS = 120_000;

type Venue = {
  id: string;
  city: string;
  name: string;
  latitude: number;
  longitude: number;
  geofence_m: number;
  active: boolean;
};

let venues: Venue[] = [];
let currentVenue: Venue | null = null;
let outsideSince = 0;
let watcherId: string | null = null;
let heartbeatTimer: ReturnType<typeof setInterval> | null = null;

function distanceM(aLat:number,aLon:number,bLat:number,bLon:number) {
  const R=6371000, p1=aLat*Math.PI/180, p2=bLat*Math.PI/180;
  const dp=(bLat-aLat)*Math.PI/180, dl=(bLon-aLon)*Math.PI/180;
  const a=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;
  return 2*R*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}

async function getInstallationId() {
  const key='hb_installation_id';
  let id=localStorage.getItem(key);
  if(!id) {
    id=crypto.randomUUID();
    localStorage.setItem(key,id);
  }
  return id;
}

async function loadVenues() {
  const { data, error } = await supabase
    .from('hb_venues')
    .select('id,city,name,latitude,longitude,geofence_m,active')
    .eq('city','Newcastle')
    .eq('active',true)
    .eq('coordinates_verified',true)
    .not('latitude','is',null)
    .not('longitude','is',null);

  if(error) throw error;
  venues = (data || []) as Venue[];
}

function matchVenue(location: BGLocation) {
  if(!location || !Number.isFinite(location.latitude) || !Number.isFinite(location.longitude)) return null;
  if(!Number.isFinite(location.accuracy) || location.accuracy > MAX_ACCURACY_M) return null;

  let best: { venue:Venue, distance:number } | null = null;
  for(const venue of venues) {
    const d=distanceM(location.latitude,location.longitude,venue.latitude,venue.longitude);
    const radius=Math.max(60, Math.min(250, venue.geofence_m || DEFAULT_RADIUS_M));
    if(d<=radius && (!best || d<best.distance)) best={venue,distance:d};
  }
  return best?.venue || null;
}

async function enterVenue(venue:Venue) {
  const installation_id=await getInstallationId();
  await supabase.rpc('hb_enter_venue', {
    p_installation_id: installation_id,
    p_venue_id: venue.id,
    p_relationship_status: localStorage.getItem('hb_relationship_status'),
    p_crowd_answer: localStorage.getItem('hb_crowd_answer'),
    p_app_version: 'gps-native-v1'
  });
}

async function heartbeat() {
  if(!currentVenue) return;
  const installation_id=await getInstallationId();
  await supabase.rpc('hb_heartbeat', {
    p_installation_id: installation_id,
    p_venue_id: currentVenue.id
  });
}

async function exitVenue() {
  if(!currentVenue) return;
  const installation_id=await getInstallationId();
  await supabase.rpc('hb_exit_venue', {
    p_installation_id: installation_id,
    p_venue_id: currentVenue.id
  });
}

async function handleLocation(location:BGLocation) {
  const matched=matchVenue(location);
  const now=Date.now();

  if(matched) {
    outsideSince=0;
    if(!currentVenue || currentVenue.id!==matched.id) {
      if(currentVenue) await exitVenue();
      currentVenue=matched;
      await enterVenue(matched);
    }
    return;
  }

  if(currentVenue) {
    if(!outsideSince) outsideSince=now;
    if(now-outsideSince>=EXIT_GRACE_MS) {
      await exitVenue();
      currentVenue=null;
      outsideSince=0;
    }
  }
}

export async function startBackgroundGPS() {
  await loadVenues();

  if(watcherId) return;

  watcherId = await BackgroundGeolocation.addWatcher(
    {
      requestPermissions: true,
      backgroundMessage: 'How Busy? is using your location to update venue crowd levels.',
      backgroundTitle: 'How Busy? location active',
      stale: false,
      distanceFilter: 50
    },
    async (location) => {
      if(location) await handleLocation(location);
    }
  );

  if(!heartbeatTimer) {
    heartbeatTimer=setInterval(() => { heartbeat().catch(console.error); }, HEARTBEAT_MS);
  }
}

export async function stopBackgroundGPS() {
  if(watcherId) {
    await BackgroundGeolocation.removeWatcher({id:watcherId});
    watcherId=null;
  }
  if(heartbeatTimer) {
    clearInterval(heartbeatTimer);
    heartbeatTimer=null;
  }
  await exitVenue();
  currentVenue=null;
}
